# CBGC · CBCKL 통합 물품관리 시스템

Vercel 운영을 전제로 만든 실제 Next.js 애플리케이션입니다.

## 주요 기능

- CBGC / CBCKL 독립 물품대장 및 테마 전환
- 관리자 서버 세션 로그인
- 물품 등록 / 조회 / 수정 / 삭제
- 모든 관리 필드 수정 및 물품대장 간 이동
- 공개정보와 관리자 전용정보 서버 레벨 분리
- QR 공개 페이지 (`/item/[publicId]`)
- QR PNG 생성
- Vercel Blob 물품사진 업로드
- Excel `.xlsx` 다운로드
- Neon PostgreSQL 영구 저장
- 모바일 반응형 UI

## 1. 설치

```bash
npm install
cp .env.example .env.local
```

## 2. 관리자 비밀번호 해시 생성

```bash
npm run hash-password -- "원하는-비밀번호"
```

출력값을 `.env.local`의 `ADMIN_PASSWORD_HASH`에 넣습니다.

## 3. Neon PostgreSQL

Vercel Marketplace에서 Neon을 프로젝트에 연결하거나 Neon에서 PostgreSQL DB를 생성한 후 `DATABASE_URL`을 설정합니다.

DB 초기화:

```bash
npm run db:init
```

## 4. Vercel Blob

Vercel 프로젝트에서 Blob Store를 연결합니다. `BLOB_READ_WRITE_TOKEN`은 연결 시 Vercel 환경변수로 주입됩니다.

## 5. 필요한 환경변수

```env
DATABASE_URL=...
BLOB_READ_WRITE_TOKEN=...
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=...
SESSION_SECRET=32자 이상의 긴 랜덤 문자열
```

## 6. 로컬 실행

```bash
npm run dev
```

## 7. 빌드 검증

```bash
npm run build
```

## 8. Git / Vercel 배포

GitHub 저장소에 이 프로젝트를 push한 뒤 Vercel에서 **Add New Project → 저장소 선택 → Deploy** 합니다.
Git 연동 후에는 `main` 브랜치 push 시 Production 배포, 다른 브랜치 및 PR은 Preview 배포가 자동 생성됩니다.

배포 전에 Vercel Project Settings → Environment Variables에 위 환경변수를 모두 등록하고, Neon DB에서 `npm run db:init`에 해당하는 스키마 초기화를 한 번 수행해야 합니다.

## 보안 설계

공개 QR 페이지는 DB 쿼리 단계에서 다음 필드만 SELECT합니다.

- 물품사진
- 보관장소
- 관리번호
- 품명
- 규격
- 취득일자
- 관리책임자(정)
- 관리책임자(부)

구매단가, 내용년수, 기타구성품, 물품분류번호, 물품식별번호는 공개 API/페이지 응답에 포함되지 않습니다.
